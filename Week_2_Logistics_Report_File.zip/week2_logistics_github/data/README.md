# Dataset Instructions

This folder is reserved for the Olist Brazilian E-Commerce Public Dataset CSV files.

Download the dataset from Kaggle:

https://www.kaggle.com/datasets/olistbr/brazilian-ecommerce

After downloading and extracting the dataset, place the required CSV files in this folder.

Expected files include:

- olist_orders_dataset.csv
- olist_order_items_dataset.csv
- olist_customers_dataset.csv
- olist_products_dataset.csv
- olist_order_payments_dataset.csv
- olist_order_reviews_dataset.csv
- olist_sellers_dataset.csv
- olist_geolocation_dataset.csv

Do not commit large raw datasets unless required. The repository can document the source and provide reproducible download instructions instead.
