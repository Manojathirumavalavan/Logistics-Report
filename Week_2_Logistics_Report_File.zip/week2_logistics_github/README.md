# Logistics Data Collection, Cleaning & Preprocessing

A Python-based data preprocessing project for logistics analytics using the **Brazilian E-Commerce Public Dataset by Olist**.

## Project Overview

This project simulates a logistics data preparation pipeline. The objective is to transform raw e-commerce order data into a reliable, analysis-ready dataset for later work such as delivery KPI analysis, delay prediction, segmentation, and logistics optimization.

### Key Areas

- Data collection and dataset profiling
- Missing-value analysis and treatment
- Duplicate detection
- Date and data-type standardization
- Business-rule validation
- Outlier detection using the IQR method
- Logistics feature engineering
- Categorical encoding
- Numerical standardization
- Data-quality validation

## Dataset

Reference dataset: **Brazilian E-Commerce Public Dataset by Olist**

The dataset contains approximately 100,000 anonymized orders from 2016–2018 and multiple related tables such as orders, order items, customers, products, payments, reviews, sellers, and geolocation.

The original dataset is not included in this repository. Download it from Kaggle and place the CSV files inside the `data/` folder.

## Project Structure

```text
logistics-data-preprocessing/
│
├── README.md
├── requirements.txt
├── preprocessing.py
│
├── data/
│   └── README.md
│
└── docs/
    └── Week_2_Logistics_Data_Cleaning_Preprocessing_Report.docx
```

## Technologies Used

- Python
- Pandas
- NumPy
- Scikit-learn
- Matplotlib

## Installation

1. Clone the repository:

```bash
git clone https://github.com/YOUR-USERNAME/logistics-data-preprocessing.git
cd logistics-data-preprocessing
```

2. Install the dependencies:

```bash
pip install -r requirements.txt
```

3. Download the Olist dataset and place the required CSV files in the `data/` directory.

4. Run the preprocessing script:

```bash
python preprocessing.py
```

## Preprocessing Workflow

```text
Raw Data
   ↓
Data Profiling
   ↓
Duplicate Detection
   ↓
Data-Type Conversion
   ↓
Missing-Value Treatment
   ↓
Business-Rule Validation
   ↓
Outlier Detection
   ↓
Feature Engineering
   ↓
Categorical Encoding
   ↓
Numerical Scaling
   ↓
Quality Checks
   ↓
Analysis-Ready Data
```

## Example Logistics Features

- `delivery_days`
- `delay_days`
- `is_late`
- `freight_ratio`

These features can support later analysis of delivery performance and transportation costs.

## Expected Outcomes

The preprocessing pipeline aims to:

- Improve data reliability
- Reduce errors and inconsistencies
- Prevent duplicate-based overcounting
- Handle missing information appropriately
- Identify suspicious extreme values
- Create meaningful logistics features
- Prepare numerical and categorical variables for machine learning

## Documentation

The detailed Week 2 report is available in:

`docs/Week_2_Logistics_Data_Cleaning_Preprocessing_Report.docx`

## Important Note

The dataset is publicly available, but the raw CSV files are intentionally not committed to this repository. This keeps the repository lightweight and avoids unnecessary duplication of the source dataset.

## Author

**Manoja T**  
B.Tech – Computer Science and Engineering
