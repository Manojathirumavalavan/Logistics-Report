import os
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler


DATA_DIR = "data"


def load_data():
    orders = pd.read_csv(os.path.join(DATA_DIR, "olist_orders_dataset.csv"))
    items = pd.read_csv(os.path.join(DATA_DIR, "olist_order_items_dataset.csv"))
    products = pd.read_csv(os.path.join(DATA_DIR, "olist_products_dataset.csv"))
    return orders, items, products


def profile_data(df, name):
    print(f"\n--- {name} ---")
    print("Shape:", df.shape)
    print("\nData types:")
    print(df.dtypes)
    print("\nMissing values:")
    print(df.isna().sum())
    print("\nDuplicate rows:", df.duplicated().sum())


def clean_orders(orders):
    # Remove true duplicate order records.
    orders = orders.drop_duplicates(subset=["order_id"]).copy()

    # Convert timestamp fields safely.
    date_cols = [
        "order_purchase_timestamp",
        "order_approved_at",
        "order_delivered_carrier_date",
        "order_delivered_customer_date",
        "order_estimated_delivery_date",
    ]

    for col in date_cols:
        if col in orders.columns:
            orders[col] = pd.to_datetime(orders[col], errors="coerce")

    # Delivery duration.
    orders["delivery_days"] = (
        orders["order_delivered_customer_date"]
        - orders["order_purchase_timestamp"]
    ).dt.total_seconds() / 86400

    # Delivery delay compared with estimated date.
    orders["delay_days"] = (
        orders["order_delivered_customer_date"]
        - orders["order_estimated_delivery_date"]
    ).dt.total_seconds() / 86400

    # Late-delivery flag.
    orders["is_late"] = (orders["delay_days"] > 0).astype(int)

    return orders


def clean_items(items):
    # Exact duplicates only; multiple rows per order are legitimate.
    items = items.drop_duplicates().copy()

    # Basic validation flags.
    items["invalid_price"] = items["price"] < 0
    items["invalid_freight"] = items["freight_value"] < 0

    # Freight-to-price ratio.
    items["freight_ratio"] = (
        items["freight_value"]
        / items["price"].replace(0, np.nan)
    )

    return items


def clean_products(products):
    products = products.copy()

    # Missing category is retained as an explicit category.
    if "product_category_name" in products.columns:
        products["product_category_name"] = (
            products["product_category_name"].fillna("Unknown")
        )

    # Median imputation for a numeric product attribute when appropriate.
    if "product_weight_g" in products.columns:
        products["product_weight_g"] = products["product_weight_g"].fillna(
            products["product_weight_g"].median()
        )

    return products


def find_iqr_outliers(df, column):
    q1 = df[column].quantile(0.25)
    q3 = df[column].quantile(0.75)
    iqr = q3 - q1
    lower = q1 - 1.5 * iqr
    upper = q3 + 1.5 * iqr

    return df[(df[column] < lower) | (df[column] > upper)]


def scale_numeric_features(df):
    features = [c for c in ["delivery_days", "delay_days"] if c in df.columns]
    model_df = df[features].dropna().copy()

    if model_df.empty:
        print("No numeric rows available for scaling.")
        return None

    train, test = train_test_split(
        model_df,
        test_size=0.20,
        random_state=42
    )

    scaler = StandardScaler()
    train_scaled = scaler.fit_transform(train)
    test_scaled = scaler.transform(test)

    print("\nScaled training sample:")
    print(train_scaled[:5])

    return train_scaled, test_scaled


def main():
    orders, items, products = load_data()

    profile_data(orders, "Orders - Raw")
    profile_data(items, "Order Items - Raw")
    profile_data(products, "Products - Raw")

    orders = clean_orders(orders)
    items = clean_items(items)
    products = clean_products(products)

    # Keep valid non-negative delivery durations for KPI analysis.
    kpi_orders = orders[
        (orders["delivery_days"] >= 0)
        & (orders["delivery_days"] <= 365)
    ].copy()

    # Detect potential freight outliers without automatically deleting them.
    freight_outliers = find_iqr_outliers(items, "freight_value")
    print("\nPotential freight outliers:", len(freight_outliers))

    print("\nClean orders shape:", orders.shape)
    print("KPI-ready orders shape:", kpi_orders.shape)
    print("Clean items shape:", items.shape)
    print("Clean products shape:", products.shape)

    scale_numeric_features(kpi_orders)


if __name__ == "__main__":
    main()
